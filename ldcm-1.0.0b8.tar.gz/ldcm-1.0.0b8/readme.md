% Longbow Cube 数据提取过程

# 概述

本文从数据请求方（即蓝豹公司）角度，说明了 Longbow Data Cube 服务（简称`LDC`）的数据处理过程。一次这样的过程被称为一个`LDC任务`。 LDC 的数据来源于 Getui 大数据系统（即 `GDW`）。因此一个`LDC任务`包含`LDC`与`GDW`的交互和数据处理与加载工作。关于`LDC`与`GDW`的交互，我们在《LBA-GAZ批量取数接口规范》（以下简称“规范”）中单独做了说明。本文假定读者已经阅读过该规范，故其内容不再赘述。

本文由 [王锦全](mailto:john.wang@longbow.com) 创建于 2016年10月。

# 状态变化过程

此处的“状态”是指某次`LDC任务`执行过程中对数据进行处理的一个或多个环节。 这种环节一般需要某个程序执行一段时间。 不同环节可能由不同程序或操作人员手工来完成。一个`LDC任务`经过的状态变化如下图所示：

         .-------(1)  ldcm   .-------(2)  flow      .-------(3)
         | rpf     |  call   | G-flow  |  running   | G-flow  |
    ---> | created | ------> | started | ---------> | done    |
         '---------'         '---------'            '---------'
                                                          |
                                               ldcm start | 
                                               loading    | 
                                                          V
                           .-------(5)   ldcm       .-------(4) 
                           | data    |   loading    | loading | 
                           | loaded  | <----------- | to cube | 
                           '---------'              '---------' 

图1： LDC任务状态跃迁

    (1)   ------>    (2)      --------->     (3)
       
    lbs              lbs                     lbs                  
     |-- 123.rpf      |-- 123.rpf.(xng|xrr)   |-- 123.rpf.(xok|xnd|xrr)
                      |-- 123.log             |-- 123.log
                                              |-- 123_0.rdf
                                              |-- 123_1.rdf

                                                  .
                                                  |
                                                  V 
      
             (5)      <---------------       (4) 
      
             lbs                             lbs                  
              |-- 123.rpf.(lok|lrr)           |-- 123.rpf.(lng|lrr)
              |-- 123.log                     |-- 123.log
              |-- 123_0.rdf                   |-- 123_0.rdf
              |-- 123_1.rdf                   |-- 123_1.rdf

图2：不同状态时`SD`中内容的变化

图1是一个`LDC任务`的状态跃迁过程。图2以示例方式展示了各状态下共享文件夹（`SD`）中文件的变化。

由上可知一个`LDC任务`会经过5个主要的状态。这些状态会体现在RPF文件后缀名和“状态行”上（详见下文）。5个状态分别是：

1. RPF文件已创建。 一个RPF文件（如“123.rpf”）的创建，标志了一个新`LDC任务`的发起。`LDC Monitor`(简称`LDCM`)程序会监控`SD`文件夹。一旦发现有新的RPF文件出现，`LDCM`会调用`GAZ`提供的接口启动对应的取数流程开始取数。

2. GAG流程已启动（或启动失败）。 一旦发起一个任务，`LDCM`会创建一个日志文件如“`123.log`”来跟踪此次任务过程，并向RPF文件名添加相应的“状态码”做后缀名。具体讲，如启动GAZ流程成功，RPF文件名将被添加后缀名“xng”；否则会被添加“xrr”。相应地“状态行”也将被更新。关于“状态码”和“状态行”请参见下文对LDCM日志文件的详细说明。

3. GAZ流程执行完毕。GAZ执行结束时，如果成功取到数据会生成结果数据文件（`RDF`），否则不会有任何输出。`LDCM`会通过轮询方式检查GAZ流程的执行状态，并相应地更新“状态行”（详见“日志文件”）和RPF文件的状态码后缀。如果一切顺利，`LDCM`随后会执行数据加载过程，即把`RDF`文件中的数据添加到Cube数据库中。这一过程启动后，`LDCM`会再次更新“状态行”和RPF文件的状态码后缀。

4. 加载数据到Cube数据库。 在这个环节`LDCM`会把`RDF`中的数据加载到Cube数据库中。

5. 数据加载完成。 此时`LDCM`完成数据加载，报表服务可以使用Cube数据库中新添加的数据了。此过程完成时，`LDCM`同样会再次修改`RPF`状态码后缀和“状态行”以标识完成状态。


# LDCM日志文件

这是一个格式化的文本文件，用来跟踪一个`LDC任务`的状态变化。该文件名采用`<任务ID>.log`的形式，如“`123.log`”。

文件内容由多个“日志”构成。一个“日志”包含一或多行内容。一个日志的最后一行是“状态行”，而其余内容为更详细日志信息。一个日志可以没有详细日志信息而只有一个“状态行”。 日志是被LDCM程序逐个添加到日志文件中的。因此，一个日志文件最后的那个日志记录了此次`LDC任务`的最近的执行状态。需要强调的是，文件中的“状态行”将被`LDCM`程序读取并按固定格式做解析。维护人员不得手工修改该行内容，否则会导致LDCM程序崩溃。

“状态行” 由 6 个字段构成，之间用一个空格分隔，即：

    <LDCM当前状态> <状态开始时戳> <GAZ流程实例ID> <GAZ当前会话ID> <会话开始时间> <会话时限>

比如：

    lng 20160930130945 8765 bs2f-a0oc-9h1m-i6al 20160930063821 86400000

其中，

* `LDCM当前状态`，是的当前状态的“状态码”，如“lng”（详见下文）。
* `时戳`，是14位的紧凑时间格式，如“20160930130945”。 
* `GAZ流程实例ID`，是GAZ平台中执行取数的流程实例（Flow Instance，有时也称为 Execution）的ID，如“8765”。为 0 表示流程实例未知。
* `GAZ当前会话ID`，接下来3个字段用来记录当前会话信息。其中本字段表示本次GAZ会话（Session）的ID。类似地，0 表示会话ID未知。
* `会话开始时间`，即建立会话的时刻。为14位的紧凑时间格式，如“20160930063821”。
* `会话时限`，GAZ允许的有效会话时长，单位“毫秒”。如“86400000”表示24小时。注意GAZ不会自动延长会话有效期。即不论期间是否有操作，一个会话总会在此会话时限到期时失效，从而需要重新登录。

LDCM定义了不同的“状态码”来表示一个`LDC任务`所处的状态。一个状态码由 3 个英文字母构成。下面是所有的状态码及其含义：

* xng 表示正在执行 GAZ 流程（eXtractiNG)
* xok 表示 GAZ 流程成功完成（eXtract OK）
* xnd 表示 GAZ 流程完成但未取到任何数据（eXtract No Data）
* xrr 表示 GAZ 流程失败（eXtract eRroR）
* lng 表示 LDCM 正在加载数据到Cube中（LoadiNG）
* lok 表示 LDCM 成功完成加载（Load OK）
* lrr 表示 LDCM 加载数据失败（Load eRroR）

# LDCM 程序

## LDCM 构成

LDCM程序由配置在Linux系统上的一组定时器服务和实现这些服务的Python程序构成。

LDCM的定时器服务是通过 [systemd](https://en.wikipedia.org/wiki/Systemd) 的 timer 来配置的。 实际的程序由 `Python2.7` 开发，并在该环境下测试通过。 程序都处在一个名为 `ldcm` 的Python包中，它们包括：

* `trgaz.py`
    
    这个程序找到`SD`下的新 `rpf` 并通过GAZ API 接口启动对应的GAZ流程开始提取数据。如启动成功，它会给 rpf 文件添加后缀 “xng” 以标明当前运行状态。如启动失败则添加后缀名“xrr”。

    此程序实现了图2中状态 “1” 到 “2” 的转换。

* `ckgflw.py`
    
    此程序通过 GAZ API 接口查看某任务的当前状态。并根据该状态更新LDCM任务日志。它实现了图2中状态 “2” 到 “3” 的转换。

* `ld2cub.py`
    
    如果成功取到数据，即存在 “XOK” 状态的任务， 此程序会加载这些任务获取的数据到Cube数据库中。它实现了图2中状态 “3” 到 “4” 以及 “4” 到 “5”的转换。根据其执行结果的不同，它同样会更新LDCM任务日志。

如前所述，上面这些程序是通过 systemd 的timer启动执行的。因此ldcm程序目前只能运行在具有systemd的Linux系统中（如 CentOS-7、Debian-8、Ubuntu-16 等以上版本）。 在安装 ldcm 时（详见下文），安装程序会创建这些定时器和相应的服务定义，并在systemd中部署并激活它们。 每个ldcm程序都有一个对应的Timer和Service定义。如 `trgaz` 程序会有 `trgaz.timer` 和  `trgaz.service`；而`ckgflw` 会有 `ckgflw.timer` 和  `ckgflw.service` 等等。为系统管理方便，这些服务都被加入到 `ldcm.target` 这个单元中，而该单元进而被加入到 systemd 的 `multi-user.target`中从而保证 ldcm 服务组能随主机一起启动。对 systemd 概念不清楚的读者，可先从网上了解，比如[这里](https://www.digitalocean.com/community/tutorials/systemd-essentials-working-with-services-units-and-the-journal)。

注意，除了通过定时器定时执行，这些程序也可以手工启动（比如等不及定时器触发，或需要调试错误时）。但手工执行前必须设置环境变量 `LDCM_CFG` 以告知 ldcm 配置文件（`ldcm.cfg`）所在的文件夹。比如下面是在命令行上手工执行一次 trgaz 程序：

    jqw$ export LDCM_CFG=/etc/longbowsh
    jqw$ python -m ldcm.trgaz

你也可以把该 `LDCM_CFG` 变量设置到自己的shell资源文件中（比如 `.bashrc`）。这样就不用每次执行程序都重复设置它。


## LDCM 安装

### 运行环境

LDCM运行时需要以下系统环境：

* 运行 Systemd 的 Linux系统，如 `Ubuntu 16.06`（推荐）、`CentOS 7` 等。
* `Python 2.7` 版本系列。ldcm 程序未在其他Python版本下测试过。
* `setuptools 23.0.0` 以上版本。这是 Python 库管理工具，ldcm 的安装程序依赖于它。
* 一个关系数据库实例，用于存储Cube数据。关于Cube数据库的结构，请参考 ldcm安装包中的 `sqls/cube.sql` 脚本。ldcm 支持以下数据库：
    * Sqlite3（主要用于测试）
    * MySQL 5 以上版本
    * PostgreSQL 9 以上版本

ldcm运行时程序依赖于以下 Python 库：

* requests >= 2.9.0
* pymysql  >= 0.7.2
* pg8000   >= 1.10.2

ldcm 的安装程序会自动下载安装这些依赖库。如自动安装失败（比如无法访问互联网），用户需手工下载安装这些库。

### 安装过程

1. 首先安装配置系统环境
    1. 安装systemd

        大部分最新版Linux系统均已采用systemd，因此我不做详述。目前我们推荐使用 `Ubuntu 16.04`系统。

    2. 安装Python

        目前均大部分最新Linux系统中均已包含了 `Python 2.7` ，因此无需安装。如确实还没有Python的，请采用系统的包管理程序（如 `yum` 或 `apt`）执行安装。

    3. setuptools 安装

        先从 [pypi](https://pypi.python.org/pypi/setuptools#downloads) 下载最新版，然后解压后执行 `python setup.py install` 即可。

    4. 安装数据库

        数据库安装请参考相应数据库的安装手册，这里不再赘述。需要提醒的是，数据库安装完毕后要创建Cube数据库对象（用户、表、视图等）。这些对象的创建脚本在 ldcm 安装包的 `sqls/cube.sql` 中，请参考。

2. 安装 ldcm 包。ldcm 包是一个标准的 Python 发布包。 因此按标准的python包安装过程执行安装即可。具体讲，
    1. 获取 ldcm 的安装包，如“`ldcm-1.0.0b1.tar.gz`”，解压缩到一临时目录
    2. 进入解压后的临时目录，如 “`cd ldcm-1.0.0b1`”
    3. 执行安装命令 “`python setup.py install`” 
        
        这一步将自动访问互联网并下载安装 ldcm 的依赖包如“requests”、 “pymysql” 等。 如主机无法联网，则所需依赖包需要安装人员手工单独安装。

3. 配置 ldcm 的systemd服务。ldcm服务的安装配置工作实现在它的安装包中，即可以通过自定义的 `setup.py` 命令自动完成 。具体讲，
    1. 执行命令 `python setup.py build_service` 来创建相应的 systemd 服务定义文件。
    2. 执行命令 `sudo python setup.py install_service` 来安装并激活（即 enable）这些服务
        
        这一命令会把ldcm相关的systemd服务定义放到systemd的配置文件夹中（通常在 `/etc/systemd/system/`），并创建ldcm的配置文件夹（通常在 `/etc/longbowsh/`）。

        注意安装并激活服务并 *不* 意味着这些服务开始工作。 要在安装后立即启动这些服务，可以在执行上述命令时提供 `-ss` 选项，如

            sudo python setup.py install_service -ss

        通常你并不希望这样做，因为安装后（强烈建议）你要先检查一下 ldcm 的配置参数（即 `/etc/longbowsh/ldcm.cfg`）无误后再启动这些服务。要手工启动这些服务，比如服务 `trgaz.timer` ，可执行命令如 `sudo systemctl start trgaz.timer` 。 

        用户可以通过 `sudo python setup.py uninstall_service` 命令来卸载这些服务。

*ldcm 的执行账户（User）*

虽然不是必须的，但我们建议让 ldcm 服务运行在普通用户而非 root 账户下。 为此上述安装步骤中 `3.2`之前的各个步骤都最好在一个普通用户的shell中执行。我们建议为 ldcm 服务专门创建一个名为 “`ldcm`”的用户，并用它来执行安装。这种情况下，第 `3.1` 步会配置systemd让它以 `ldcm` 用户执行ldcm的各个程序，采用的 Python 解释器也是 `ldcm` 用户下的。但由于安装这些服务到systemd环境中必须具有 root 权限，所以在第 `3.2` 步中我们使用了 `sudo` 。

至此整个 ldcm 程序安装完毕。安装后请检查（必要时修改）ldcm 的配置，即 `/etc/longbowsh/ldcm.cfg` 文件。确保配置无误后再启动服务。


## Cube 数据库结构

我们将为不同的GAZ取数流程建立各自对应的一张表来存放取出的数据，这被称为“主数据表”。鉴于RDF记录中标签值的特殊输出方式（参见《规范》），主数据表的字段结构与RDF记录结构并不严格一直。同时为了方便在Cube中对数据做进一步处理（比如设计报表），我们为主数据表创建了相应的一个视图，通过该视图的列定义对主数据表的列值做了相应转换。请参考 ldcm 安装包中的 “`sqls/cube.sql`” 文件了解Cube数据库结构详情。

