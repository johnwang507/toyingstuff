#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Getui 大数据平台提供的 tag 字典是 JSON 格式的。 本小程序把它转成简单的空格分隔的列式文本。即把：
#
# {
#     "category": {
#         "1": [
#             {
#                 "group": "age",
#                 "desc": "年龄",
#                 "list": [
#                     {
#                         "id": "011100",
#                         "desc": "0-17岁"
#                     },
#                     {
#                         "id": "011200",
#                         "desc": "18～24岁"
#                     },
#     ... ...
# 
# 变成：
# 
#    tag-age 年龄
#    011100  0-17岁
#    011200  18～24岁
#    ... ...

import json
import sys

def main():
    if len(sys.argv)<2:
        print 'Err: missing input file. Syntax:', sys.argv[0], '<json file>'
        sys.exit(2)
    with open(sys.argv[1], 'r') as ff:
        tagj = json.load(ff)
    tags = sum(tagj['category'].values(), [])
    for tag in tags:
        print ('tag-' + tag['group'] + ' ' + tag['desc']).encode('utf-8')
        for opt in tag['list']:
            print (opt['id'] + ' ' + opt['desc']).encode('utf-8')

if __name__ == '__main__':
    main()

