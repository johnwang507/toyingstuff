#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Author: john.wang@longbow.com
# Date: Oct/2016
#
# Utility functions for LDCM

import re
import os
import sys
import glob
import codecs
import time
import datetime
import hashlib
import requests

DT_FMT = '%Y%m%d%H%M%S'

JOB_STAT_XNG = 'xng' # GAZ 正在取数中
JOB_STAT_XOK = 'xok' # GAZ 取数完成( RDF 已经生成)
JOB_STAT_XNO = 'xnd' # GAZ 取数完成但未取到任何数据
JOB_STAT_XRR = 'xrr' # GAZ 取数异常
JOB_STAT_LNG = 'lng' # LDCM 正在向 Cube 加载数据
JOB_STAT_LOK = 'lok' # LDCM 完成数据加载
JOB_STAT_LRR = 'lrr' # LDCM 数据加载异常

CONFIG_ROOT = os.environ.get('LDCM_CFG', os.path.join(os.path.dirname(__file__), '..', 'config'))
CONFIG_PATH = os.path.join(CONFIG_ROOT, 'ldcm.cfg')
TAG_DAT_PATH = os.path.join(CONFIG_ROOT, 'tags4db.dat')

CONFIG_VAR=(
    (str,  'SD_PATH'),
    (str,  'GAPI_ROOT'),
    (str,  'GAPI_LOGIN'),
    (str,  'GAPI_EXECFLOW'),
    (str,  'GAPI_FLOWSTATE'),
    (str,  'GAZ_PARTY_FLAG'),
    (int,  'GAZ_USERTYPE'),
    (str,  'GAZ_PROJECT'),
    (str,  'GAZ_FLOW_LBS'),
    (str,  'GAZ_FLOW_MBX'),
    (str,  'GAZ_USER'),
    (str,  'GAZ_PWD'),
    (str,  'CUBE_LBS_TBL'),
    (str,  'CUBE_MBX_TBL'),
    (str,  'DB_ENGINE'),
    (str,  'DB_HOST'),
    (int,  'DB_PORT'),
    (str,  'DB_DB'),
    (str,  'DB_CHARSET'),
    (str,  'DB_USER'),
    (str,  'DB_PWD'),
)

STAT_LINE_RGX=re.compile(r'[a-zA-Z0-9]{3} \d{14} \d+ [a-zA-Z0-9_\-]+ \d{14} \d+')

def cfgvc(tp, nm, cfg):
    try:
        return tp(next(v for k,v in cfg if nm==k))
    except :
        raise Exception('Err: config for var "%s" missed or wrong type'%nm)

def load_cfg():
    with codecs.open(CONFIG_PATH, 'r',encoding='utf-8') as ff:
        cfg_vals = [l.partition('=') for l in ff
            if l.strip() and \
               (not l.strip().startswith('#')) and \
               ('=' in l)]
    cfg_vals = [(k.strip(),  v.partition('#')[0].strip()) for k,_,v in cfg_vals]
    return dict((nm, cfgvc(tp, nm, cfg_vals)) for tp,nm in CONFIG_VAR)
cfg = load_cfg()

def gaz_sign(tmst):
    '''Generate login sign for GAZ. *tmst* is a long int, as a timestamp in milliseconds from epoch. Generating rule: md5(username + thirdpartflag + md5(password) + timestamp)'''
    sign_eles = (cfg['GAZ_USER'], cfg['GAZ_PARTY_FLAG'],
                    hashlib.md5(cfg['GAZ_PWD']).hexdigest(), str(tmst))
    return hashlib.md5(''.join(sign_eles)).hexdigest()

def curr_time(as_milli_sec=True):
    millis = int(round(time.time() * 1000))
    if as_milli_sec:
        return millis
    return datetime.datetime.fromtimestamp(millis/1000.0)

def milli_sec(dt, fmt):
    epoch = datetime.datetime.utcfromtimestamp(0)
    dt = datetime.datetime.strptime(dt, fmt)
    return (dt - epoch).total_seconds() * 1000.0

# Compose the path of these special files
def compath_logf(flowtype, jobid):
    return os.path.join(cfg['SD_PATH'], cfg['GAZ_PROJECT'], flowtype, '%s.log' % jobid)
def compath_rpf(flowtype, jobid='*', stat=None):
    sfx = stat and ('.%s' % stat) or ''
    return os.path.join(cfg['SD_PATH'], cfg['GAZ_PROJECT'], flowtype, '%s.rpf%s' % (jobid, sfx))

def compath_rdfs(flowtype, jobid):
    path_exp = os.path.join(cfg['SD_PATH'], cfg['GAZ_PROJECT'], flowtype, '%s_[0-9]*.rdf' % jobid)
    return glob.glob(path_exp)

def jobid_from(rpf):
    fname = os.path.basename(rpf)
    if fname.upper().endswith('.RPF'):
        return fname[:-4]
    else:
        return fname[:-8] # status code is always 3 chars long

def find_rpfs(stat=None, flowtype=None):
    '''Find all LDC Jobs in the specified *stat* and Flow Type *flowtype*. Return a list of 2-tuple of str as Job ID and GAZ Flow Type. If *stat* is not specified(i.e., any falsy values), return all new jobs.'''
    if flowtype:
        return [(jobid_from(rpf), flowtype) for rpf in glob.glob(compath_rpf(flowtype, stat=stat))]
    else:
        return [(jobid_from(rpf), cfg['GAZ_FLOW_LBS']) for rpf in glob.glob(compath_rpf(cfg['GAZ_FLOW_LBS'], stat=stat))] \
            + [(jobid_from(rpf), cfg['GAZ_FLOW_MBX']) for rpf in glob.glob(compath_rpf(cfg['GAZ_FLOW_MBX'], stat=stat))]

def chg_rpf_sfx(flowtype,jobid,stat):
    '''Add or update the rpf filename suffix to reflect the current LDC job status. If the suffix is already *stat* , do nothing.'''
    base_rpf = compath_rpf(flowtype,jobid)
    new_rpf = base_rpf + '.' + stat
    old_rpf = glob.glob(base_rpf + '.*')
    if old_rpf:
        old_rpf = old_rpf[0]
        old_stat = old_rpf.rpartition('.')[2]
        if stat != old_stat:
            os.rename(old_rpf, new_rpf)
    else:
        os.rename(base_rpf, new_rpf)

def read_stat(jobid, flowtype, logfop=False):
    '''Read in the last line, i.e., the "status line" of the log file. If *logfop* is True, return the "status line" and the log file as a 2-tuple, otherwise only the former returned'''
    logf = compath_logf(flowtype, jobid)
    if not os.path.exists(logf):
        open(logf, 'a').close()
    stat_line = None
    logf = codecs.open(logf, logfop and 'r+' or 'r', encoding='utf-8')
    for line in logf:
        sline = line.strip()
        if sline and STAT_LINE_RGX.match(sline):
            stat_line = sline
    if logfop:
        return stat_line, logf
    else:
        logf.close()
        return stat_line

def add_log(flowtype, jobid, flowiid=None, sta=None, session=None, msg=''):
    '''Add a log to log file. *flowiid*, *sta* andn *session* are the GAZ execution ID, status code and the session(3-tuple) in which the execution is started. If they are None, they will be kept as the last log. '''
    l_line, logf = read_stat(jobid, flowtype, True)
    l_els = l_line and l_line.split() or [0]*6
    l_sta, l_fiid, l_sess = l_els[0], int(l_els[2]), l_els[3:]
    if not (l_sta or sta):
        raise Exception('Unknown state of ldcm job')
    n_sta = sta or l_sta
    n_fiid = flowiid or l_fiid
    n_sess = session or l_sess
    if msg:
        logf.write(msg+'\n')
    stat_line = [n_sta, curr_time(0).strftime(DT_FMT), n_fiid] + list(n_sess)
    log = '%s %s %s %s %s %s\n' % tuple(stat_line)
    logf.write(log)
    logf.close()
    return log

def session_due(session, mmnt=None):
    '''How long(in millisecond) will the *session* be valid from *mmnt*, a timestamp in millisecond from epoch. If *mmnt* is None, it'll be taken as current time.'''
    mmnt = mmnt or curr_time()
    _, sstart, sstimeout = session
    return milli_sec(sstart, DT_FMT) + long(sstimeout) - mmnt

def get_session(jobid, flowtype, min_time_left=30000):
    '''Get session info from the log file. If the session remaining valid time is greater then *min_time_left* , return the session as a 3-tuple of strings as id, start time, and timeout(in millisecond) of this session. Otherwise return None.'''
    stat_line = read_stat(jobid, flowtype)
    if not stat_line:
        return None
    session = stat_line.split()[3:]
    if session[0] == '0' or session_due(session) < min_time_left:
        return None
    else:
        return tuple(session)

def init_session():
    '''Login to GAZ to establish a session. Return a 3-tuple of strings as id, start time, and timeout(in millisecond) of this new session. If login failed, return None. '''
    api_login = cfg['GAPI_ROOT'] + cfg['GAPI_LOGIN']
    tmst = curr_time()
    res = requests.post(api_login,
                json={"username":    cfg['GAZ_USER'],
                    "sign":          gaz_sign(tmst),
                    "timestamp":     tmst,
                    "usertype":      cfg['GAZ_USERTYPE'],
                    "thirdpartflag": cfg['GAZ_PARTY_FLAG'] })
    rv = res.json()
    if rv['code'] != '0':
        return None
    else:
        sstart = datetime.datetime.fromtimestamp(tmst/1000.0).strftime(DT_FMT)
        return rv['session.id'], sstart, rv['session.timeout']

def conn_db():
    if cfg['DB_ENGINE'].lower() == 'mysql':
        import pymysql as db
    elif cfg['DB_ENGINE'].lower() == 'postgresql':
        import pg8000 as db
    else:
        import sqlite3
        return sqlite3.paramstyle, sqlite3.connect(cfg['DB_DB'])
    try:
        return db.paramstyle, db.connect(
                    host     = cfg['DB_HOST'],
                    port     = cfg['DB_PORT'],
                    db       = cfg['DB_DB'],
                    user     = cfg['DB_USER'],
                    password = cfg['DB_PWD'],
                    charset  = cfg['DB_CHARSET'] )
    except:
        raise Exception('Err: DB on %(DB_HOST)s:%(DB_PORT)d:%(DB_DB)s not ready yet'%cfg)

def boot_frame(mainfn):
    if len(sys.argv)>1:
        flowtype = sys.argv[1]
    else:
        flowtype = None
    if flowtype is None or flowtype in (cfg['GAZ_FLOW_LBS'], cfg['GAZ_FLOW_MBX']):
        mainfn(flowtype)
    else:
        print 'Err: Flow type "%s" not defined' % flowtype
        sys.exit(2)

