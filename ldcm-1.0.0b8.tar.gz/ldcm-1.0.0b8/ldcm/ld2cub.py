#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Author: john.wang@longbow.com
# Date: Oct/2016
#
# Load data to Cube

import traceback
import codecs
from contextlib import closing
import utils   # Supporting functions of LDCM

# 目前LBS和“盒子”两种取数方式采用相同的数据结构。但为了将来的变化，
# 还是分建了两张结构相同的表，表名由配置参数 CUBE_LBS_TBL 和 CUBE_MBX_TBL 指定。
tblcol = (
    'group_id',
    'device_id',
    'resd_lan',
    'resd_lat',
    'capt_time',
    'age',
    'gender',
    'cnsum_lvl',
    'mari_sta',
    'occupa',
    'car_ownr',
    'langu',
    'phn_brand',
    'resd_ctier',
    'resd_city',
    'parent',
    'recn_acts',
    'sex_orien',
    'finance',
    'shopping',
    'education',
    'travel',
    'autom',
    'reading',
    'video',
    'social_net',
    'life_serv',
    'fitness',
    'photo',
    'maternal',
    'utils',
    'prodv',
    'tel_opr', )

# All the tags in the Getui DW with the following struc:
# {"tag_name db_col_name, single_or_multi": [t1, t2, t3], ...}
# It will be inited at boot time(i.e., in main func)
tagdefs = None

sql_tpl = '''INSERT INTO %s (%s) VALUES (%s)'''

def gpsv(val, is_lan):
    vals = val.split('/')
    if len(vals)<2:
        return None
    return is_lan and int(float(vals[0])*1000) or int(float(vals[1])*1000)

def tagv(tdef, vs):
    '''construct the proper value for DB insert. Single-value tag will be a string inserted as-is, while multi-value tag will be an integer with corresponded bits set for its values'''
    if tdef[-1] == 's':
        if len(vs)>1:
            raise Exception('RDF err: multiple values%s found for single tag "%s"' % (vs, tdef.split()[0]))
        return vs[0]
    else:
        return int(''.join((v in vs) and '1' or '0' for v in tagdefs[tdef]), 2)

def ptags(vals):
    rt = {}
    for v in vals:
        tdef = next((t for t, vs in tagdefs.items() if v in vs), None)
        if not tdef:
            raise Exception('RDF err: undefined tag: %s' % v)
        tvs = rt.get(tdef, None)
        rt[tdef] = (tvs and tvs + [v]) or [v]
    return dict((k.split()[-2], tagv(k, vs)) for k, vs in rt.items())

def pparams(line):
    vals = [l.strip() for l in line.split(',')]
    params = dict((c, None) for c in tblcol) #Default None
    params.update(group_id  = (vals[0] or None),
                  device_id = (vals[1] or None),
                  resd_lan  = gpsv(vals[2], 1),
                  resd_lat  = gpsv(vals[2], 0),
                  capt_time = (vals[3] or None))
    params.update(ptags(vals[4].split('/')))
    return params

sql_pv_seq = lambda x:[x.get(c, None) for c in tblcol]
param_procs = ( # style value, placeholder generator, values generator
    ('qmark',    (lambda:','.join('?'*len(tblcol))),                         sql_pv_seq),
    ('numeric',  (lambda:','.join(':%d'%(i+1) for i in range(len(tblcol)))), sql_pv_seq),
    ('named',    (lambda:','.join(':%s'%c for c in tblcol)),                 lambda x:x),
    ('format',   (lambda:','.join([r'%s']*len(tblcol))),                     sql_pv_seq),
    ('pyformat', (lambda:','.join('%'+'(%s)s'%c for c in tblcol)),           lambda x:x), )

def insert(flowtype, lines, curs, conn, paramstyle):
    params = [pparams(line) for line in lines]
    tbl_name = (flowtype==utils.cfg['GAZ_FLOW_LBS'] and utils.cfg['CUBE_LBS_TBL'] or utils.cfg['CUBE_MBX_TBL'])
    phfn, valfn = next((pfn, vfn) for sty, pfn, vfn in param_procs if sty==paramstyle)
    curs.executemany(sql_tpl %(tbl_name,  ','.join(tblcol), phfn()), [valfn(p) for p in params])
    conn.commit()
    return len(params)

def loadf2db(flowtype, rdf, curs, conn, paramstyle):
    num = 0
    with codecs.open(rdf, 'r', encoding='utf-8') as ff:
        batch = []
        for line in ff:
            dline = line.strip()
            if not dline:continue
            batch.append(dline)
            if len(batch)>=1000: # Batch limit
                num = num + insert(flowtype, batch, curs, conn, paramstyle)
                batch = []
        if batch:
            num = num + insert(flowtype, batch, curs, conn, paramstyle)
    return num

def update_state(jobid,flowtype,sta, msg=''):
    utils.chg_rpf_sfx(flowtype, jobid, sta)
    return utils.add_log(flowtype, jobid, sta=sta, msg=msg)

def load_tagdefs():
    defs = {}
    last_tag, last_vals = None, []
    with codecs.open(utils.TAG_DAT_PATH, 'r', encoding='utf-8') as ff:
        for l in ff:
            line = l.strip()
            if line.startswith('#'):continue
            if line.startswith('tag-'):
                if last_tag:
                    defs[last_tag] = last_vals
                last_tag, last_vals = line.lstrip('tag-'), []
            else:
                last_vals.append(line)
        if last_tag:
            defs[last_tag] = last_vals
    return defs

def main(flowtype=None):
    '''Find all "xok" job and load their data into Cube. Return a list of the lastest "status line" for every job.'''
    xok_jobs = utils.find_rpfs(utils.JOB_STAT_XOK, flowtype)
    paramstyle, conn = utils.conn_db()
    try:
        with closing(conn.cursor()) as curs:
            for j,f in xok_jobs:
                update_state(j,f,utils.JOB_STAT_LNG)
                try:
                    rdfs = utils.compath_rdfs(f, j)
                    [loadf2db(f, rdf, curs, conn, paramstyle) for rdf in rdfs]
                except Exception as e:
                    update_state(j,f,utils.JOB_STAT_LRR, traceback.format_exc(8))
                    raise e
                update_state(j,f,utils.JOB_STAT_LOK)
    finally:
        conn.close()

if __name__ == '__main__':
    tagdefs = load_tagdefs()
    utils.boot_frame(main)

