#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Author: john.wang@longbow.com
# Date: Oct/2016
#
# Start the GAZ flow

import os
import requests
import traceback
import utils   # Supporting functions of LDCM

def update_stat(stat, aux_msg=''):
    '''Create a function to set the status of current LDC Job. The returned function taking 4 args: flowtype, jobid, session and rdict. The *session* is a 3-tuple for id, start time and timeout of the session. The *rdict* is a dict object as the reponsed json.'''
    def fun(flowtype, jobid, session, rdict):
        utils.chg_rpf_sfx(flowtype, jobid,stat)
        return utils.add_log(flowtype, jobid, rdict.get('execid', 0), stat, session, rdict.get('errorMsg', aux_msg).strip())
    return fun

resp_funs = dict((
    ('0',   update_stat(utils.JOB_STAT_XNG)),
    ('100', update_stat(utils.JOB_STAT_XRR, u'gaz err: 100 通用错误')),
    ('101', update_stat(utils.JOB_STAT_XRR, u'gaz err: 101 没有登录')),
    ('102', update_stat(utils.JOB_STAT_XRR, u'gaz err: 102 不存在该用户')),
    ('103', update_stat(utils.JOB_STAT_XRR, u'gaz err: 103 没有权限')),
    ('301', update_stat(utils.JOB_STAT_XRR, u'gaz err: 301 参数错误')),
))

def start_gazflow(jobid, flowtype):
    api_execflow = utils.cfg['GAPI_ROOT'] + utils.cfg['GAPI_EXECFLOW']
    session = utils.get_session(jobid, flowtype) or utils.init_session()
    res = requests.post(api_execflow, json={
                                    "session.id":    session[0],
                                    "project":       utils.cfg['GAZ_PROJECT'],
                                    "flow":          flowtype,
                                    "flowOverride[rpfpath]":os.path.dirname(utils.compath_rpf(flowtype)),
                                    "flowOverride[ldcjob]":jobid,
                                 } )
    rv = res.json()
    return resp_funs[rv['code']](flowtype, jobid, session, rv)

def main(flowtype=None):
    '''Start GAZ Flows for all new jobs. Return a list of new "status line" for every job.'''
    new_jobs = utils.find_rpfs(flowtype=flowtype)
    for jid, ftp in new_jobs:
        try:
            start_gazflow(jid, ftp)
        except:
            utils.chg_rpf_sfx(ftp, jid, utils.JOB_STAT_XRR)
            utils.add_log(ftp, jid, flowiid=0,
                    sta=utils.JOB_STAT_XRR,
                    msg=traceback.format_exc(8))
            break

if __name__ == '__main__':
    utils.boot_frame(main)
