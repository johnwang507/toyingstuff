#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Author: john.wang@longbow.com
# Date: Oct/2016
#
# Check status of specified executing GAZ Flows(in “xng” state) to see if they've done/failed.

import traceback
import requests
import utils   # Supporting functions of LDCM

def logfn(aux_msg, stat=utils.JOB_STAT_XNG):
    def fun(jobid, session, rdict):
        flowtype = rdict['flow']
        execid = rdict.get('execid', 0)
        msg = rdict.get('errorMsg', aux_msg).strip()
        return utils.add_log(flowtype, jobid, execid,
            stat, session, msg)
    return fun

def update_stat(jobid, session, rdict):
    '''Update rpf filename suffix and add new log. *rdict* is the responsed dict from GAZ execution. GAZ status in it can be one of: PREPARING,READY,PAUSED,RUNNING,KILLED,SUCCEEDED,FAILED Return the new log.'''
    flowtype = rdict.get('flow', '0')
    if rdict['status'] == 'SUCCEEDED':
        rdfs = utils.compath_rdfs(flowtype, jobid)
        n_sta = rdfs and utils.JOB_STAT_XOK or utils.JOB_STAT_XNO
        utils.chg_rpf_sfx(flowtype, jobid, n_sta)
        return logfn('', n_sta)(jobid, session, rdict)
    elif rdict['status'] in ('KILLED', 'FAILED'):
        utils.chg_rpf_sfx(flowtype, jobid, utils.JOB_STAT_XRR)
        return logfn(u'gaz status: %s' % rdict['status'], utils.JOB_STAT_XRR)(jobid, session, rdict)
    else:
        return logfn(u'gaz status: %s' % rdict['status'])(jobid, session, rdict)

resp_funs = dict((
    ('0',   update_stat),
    ('100', logfn(u'gaz err:100 通用错误')),
    ('101', logfn(u'gaz err:101 没有登录')),
    ('102', logfn(u'gaz err:102 不存在该用户')),
    ('103', logfn(u'gaz err:103 没有权限')),
    ('301', logfn(u'gaz err:301 参数错误')),
))


def ck_gflw(jobid, flowiid, session):
    '''Check GAZ execution and update the state of the LDC jobs. *flowiid* is the execution ID as an int. *session* is a 3-tuple as the session. Return one of the status of GAZ Flow: PREPARING, READY, PAUSED, RUNNING, KILLED, SUCCEEDED, FAILED. Also, add the status to the log and update RPF file suffix if needed.'''
    api_flowstate = utils.cfg['GAPI_ROOT'] + utils.cfg['GAPI_FLOWSTATE']
    res = requests.post(api_flowstate, json={
                            "session.id": session[0],
                            "execid":     flowiid } )
    rv = res.json()
    return resp_funs[rv['code']](jobid, session, rv)

def err_sta(jid, fwtp):
    utils.chg_rpf_sfx(fwtp, jid, utils.JOB_STAT_XRR)
    utils.add_log(fwtp, jid, sta=utils.JOB_STAT_XRR, msg=traceback.format_exc(8))

def main(flowtype=None):
    '''Check the status of all jobs in "xng" state. Return a list of new "status line" for every job.'''
    xng_jobs = utils.find_rpfs(utils.JOB_STAT_XNG, flowtype)
    if not xng_jobs:
        return []
    stat_lines = [[jid, fwtp] + utils.read_stat(jid,fwtp).split() for jid, fwtp in xng_jobs]
    currt = utils.curr_time()
    try:
        session = max(stat_lines, key=lambda x:utils.session_due(x[5:], currt))[5:]
        if utils.session_due(session, currt) < 2*60*1000: # 少于2分钟则重建会话
            session = utils.init_session()
    except:
        return err_sta(*xng_jobs[0])
    for sta in stat_lines:
        jid, fwtp, fiid = sta[0], sta[1], int(sta[4])
        try:
            ck_gflw(jid, fiid, session)
        except:
            return err_sta(jid, fwtp)

if __name__ == '__main__':
    utils.boot_frame(main)
