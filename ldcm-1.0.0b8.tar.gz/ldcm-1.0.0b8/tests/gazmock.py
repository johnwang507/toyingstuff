#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# A mock of GAZ RESTful API server for testing MDCM.

from flask import Flask, request, jsonify
import json
import sys
import pprint
import os

# curl -X POST -H "Content-Type: application/json" -d '{"username":"foo","sign":"xyz143731", "thirdpartflag":"mbarena","usertype":1, "timestamp":143731}' http://127.0.0.1:5000/login.htm

app = Flask(__name__)

@app.route("/<test_request>", methods=['POST'])
def uni_handler(test_request):
    pprint.pprint(['Posted:', request.get_json()])
    respf = 'gazmock/%s/%s.resp' %(app.tcase, test_request.strip('.htm'))
    respf = os.path.join(os.path.dirname(__file__), respf)
    with open(respf, 'r') as ff:
        data = json.load(ff)
    return jsonify(**data)

if __name__ == "__main__":
    app.tcase = sys.argv[1:] and sys.argv[1] or 'scen1'
    app.run()
