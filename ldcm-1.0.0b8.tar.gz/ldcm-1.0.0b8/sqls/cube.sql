-- Cube Database structure(MySQL Dialect)
CREATE DATABASE IF NOT EXISTS lbcube CHARACTER SET utf8;
CREATE USER IF NOT EXISTS 'cudba'@'%' IDENTIFIED BY '111';
GRANT ALL PRIVILEGES ON lbcube.* TO 'cudba'@'%' WITH GRANT OPTION;

-- 用于存储LBS数据的主数据表
CREATE TABLE IF NOT EXISTS lbcube.gaz_lbs (
  id         INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  load_time  TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '入库时间',
  group_id   VARCHAR(30) NOT NULL COMMENT '分组标识',
  device_id  VARCHAR(64) NOT NULL COMMENT '设备标识的MD5值(hexdigest)',
  resd_lan   INT COMMENT '居住地的经度。范围 180000 ~ -180000。源数据精确到小数后3位，此处放大1千倍保存为整数。Null或0表示位置未知',
  resd_lat   INT COMMENT '居住地的维度。范围 90000 ~ -90000。源数据精确到小数后3位，此处放大1千倍后保存为整数。Null或0表示位置未知',
  capt_time  VARCHAR(150) COMMENT '多个“紧凑时间格式”字符串，之间用“/”分隔，表示在地理围栏里多次出现的时间。如 “20160812185409/20160812213352”',
  --
  -- ##########    标签字段    ##########
  --
  -- 单值二级标签。将保存Getui数据平台中定义的三级标签的编码
  --
  age        CHAR(6) COMMENT '年龄: 011100 0-17岁, 011200 18～24岁, 011300 25～34岁, 011400 35岁+',
  gender     CHAR(6) COMMENT '性别: 012100 女 012200 男',
  cnsum_lvl  CHAR(6) COMMENT '消费水平: 014100 低, 014200 中, 014300 高',
  mari_sta   CHAR(6) COMMENT '婚姻: 015100 未婚 015200 找对象 015300 已婚',
  occupa     CHAR(6) COMMENT '职业: 016100 中小学生 016200 大学生 016300 求职中 016400 白领 016700 程序员 016800 医生 016600 教师',
  car_ownr   CHAR(6) COMMENT '是否是车主: 01c100 有车',
  langu      CHAR(4) COMMENT '手机语言: 0901 中文简体 0902 中文繁体 0903 英语 0904 朝鲜语 0905 印度语 0906 越南语 0907 土耳其语 0908 日语 0909 阿拉伯语 0910 西班牙语 0911 意大利语 0912 葡萄牙语 0913 马来语 0914 荷兰语 0915 朝鲜语 0916 荷兰语 0917 俄语 0918 泰语',
  phn_brand  CHAR(4) COMMENT '手机品牌: 0848 小米 0844 华为 0841 苹果 0849 OPPO 084a 三星 084b Vivo 0847 魅族 0842 酷派 0845 联想 0843 金立 0846 乐视',
  resd_ctier CHAR(6) COMMENT '几线城市: 01a100 一线城市 01a200 二线城市 01a300 三线城市 01a400 三线以下城市',
  resd_city  CHAR(9) COMMENT '所在城市。可选值参见相应的三级标签编码',
  --
  -- 多值二级标签。以一个整数中的对应位(bit)表示该记录具备的多个三级标签。具体说明如下：
  --
  -- 为提高存储效率并支持以后三级标签的增加，二级标签字段都采用4字节的INT型，
  -- 并按顺序用低位bit表示该三级标签是否存在。这样一个二级标签最多允许 32 个三级标签。
  -- 比如“运营商”包含 4 个三级标签“电信、移动、联通、其他”，则该字段的一个可能值就可以是
  -- “00000000 00000000 00000000 00000110”。这表示它具备“移动、联通”两个三级标签
  -- 而没有“电信、其他”，因为其最后4位是“0110”。各字段值中三级标签的顺序按以下注释所示。
  -- 注意注释中提供了各三级标签的编码，它们仅做参考之用，并不会保存到表中。
  --
  parent INT COMMENT '有小孩情况',
  -- 013100 备孕
  -- 013200 孕期
  -- 013300 0-2岁小孩父母
  -- 013400 3-6岁小孩父母
  -- 013700 妈妈
  -- 013800 母婴
  -- 013500 小学生家长
  -- 013600 中学生家长
  recn_acts INT COMMENT '最近行为',
  -- 041000 搬家
  -- 042001 国内旅游
  -- 042002 出境游
  sex_orien INT COMMENT '性取向',
  -- 01b100 男同
  -- 01b200 女同
  -- 01b300 异性恋
  finance INT COMMENT '金融理财',
  -- 021100 股票交易
  -- 021200 投资理财
  -- 021300 记账
  -- 021400 银行
  -- 021500 信用卡
  -- 021600 彩票
  -- 021700 网贷p2p
  shopping INT COMMENT '购物',
  -- 022100 网购
  -- 022200 海淘
  -- 022300 快递
  -- 022400 酒类
  -- 022500 团购
  education INT COMMENT '教育',
  -- 023100 学前教育
  -- 023200 中小学教育
  -- 023300 成人教育
  -- 023400 英语培训
  -- 023500 出国培训
  -- 023600 考试证书
  -- 023700 语言学习
  -- 023800 在线教育
  travel INT COMMENT '旅游',
  -- 024100 商务旅行
  -- 024200 休闲旅行
  -- 024300 酒店·住宿
  -- 024400 户外
  -- 024500 周边游
  autom INT COMMENT '汽车',
  -- 025100 租车
  -- 025200 买车
  -- 025300 驾考
  -- 025400 爱车
  -- 025500 代驾
  -- 026600 违章查询
  reading INT COMMENT '新闻阅读',
  -- 026100 新闻·资讯
  -- 026200 杂志
  -- 026300 小说
  -- 026400 听书
  -- 026500 漫画
  -- 026600 搞笑
  -- 026700 画报
  -- 026800 体育资讯
  video INT COMMENT '影音',
  -- 027100 K歌
  -- 027200 音乐播放器
  -- 027300 电台
  -- 027400 铃声
  -- 027500 视频播放器
  -- 027600 电视直播
  -- 027700 在线视频
  -- 027800 在线音乐
  social_net INT COMMENT '聊天社交',
  -- 028100 聊天
  -- 028200 单身交友
  -- 028300 婚恋
  -- 028400 微博
  -- 028500 社区
  life_serv INT COMMENT '生活服务',
  -- 029100 餐厅推荐
  -- 029200 外卖
  -- 029300 生鲜配送
  -- 029400 找阿姨
  -- 029500 洗衣
  -- 029600 做饭
  -- 029700 按摩
  -- 029800 电影
  -- 029900 宠物
  -- 029a00 租房
  -- 029b00 搬家
  -- 029c00 买房
  -- 029d00 家装
  -- 029e00 婚礼
  fitness INT COMMENT '运动健康',
  -- 02a100 运动健身
  -- 02a200 减肥
  -- 02a300 健康医疗
  -- 02a400 慢性病
  photo INT COMMENT '图像',
  -- 02b100 拍摄美化
  -- 02b200 图片分享
  -- 02b300 摄像
  maternal INT COMMENT '丽人母婴',
  -- 02c100 美容美妆
  -- 02c200 育儿社区
  -- 02c300 经期
  utils INT COMMENT '生活实用',
  -- 02d100 打车出行
  -- 02d200 美食菜谱
  -- 02d300 地图导航
  -- 02d400 天气查询
  prodv INT COMMENT '效率办公',
  -- 02e100 存储云盘
  -- 02e200 办公软件
  -- 02e300 笔记
  -- 02e400 邮箱
  tel_opr INT COMMENT '运营商'
  -- 086a 中国移动
  -- 086b 中国联通
  -- 086c 中国电信
  -- 0860 其他运营商
);

-- 由于主数据表对多值标签按“位”存储，为统计计算方便，定义相应的视图把这些“位”转换成相应的布尔型字段。
CREATE OR REPLACE VIEW lbcube.v_gaz_lbs AS
  SELECT
    id,        -- INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    load_time, -- TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '入库时间',
    group_id,  -- VARHCAR(30) NOT NULL COMMENT '分组标识',
    device_id, -- VARCHAR(64) NOT NULL COMMENT '设备标识的MD5值(hexdigest)',
    resd_lan/1000.0,  -- FLOAT COMMENT 'GPS经度。如“121.535”。Null或0时表示位置未知',
    resd_lat/1000.0,  -- FLOAT COMMENT 'GPS维度。如“23.981”。Null或0时表示位置未知',
    capt_time, -- VARCHAR(150) COMMENT '多个“紧凑时间格式”字符串，之间用“/”分隔，表示在地理围栏里多次出现的时间。如 “20160812185409/20160812213352”',
    --
    -- ##########    标签字段    ##########
    --
    -- 以下是单值二级标签字段。将保存Getui数据平台中定义的三级标签的编码
    age,        -- CHAR(6) COMMENT '年龄: 011100 0-17岁, 011200 18～24岁, 011300 25～34岁, 011400 35岁+',
    gender,     -- CHAR(6) COMMENT '性别: 012100 女 012200 男',
    cnsum_lvl,  -- CHAR(6) COMMENT '消费水平: 014100低, 014200中, 014300高',
    mari_sta,   -- CHAR(6) COMMENT '婚姻: 015100 未婚 015200 找对象 015300 已婚',
    occupa,     -- CHAR(6) COMMENT '职业: 016100 中小学生 016200 大学生 016300 求职中 016400 白领 016700 程序员 016800 医生 016600 教师',
    car_ownr,   -- CHAR(6) COMMENT '是否是车主: 01c100 有车',
    langu,      -- CHAR(4) COMMENT '手机语言: 0901 中文简体 0902 中文繁体 0903 英语 0904 朝鲜语 0905 印度语 0906 越南语 0907 土耳其语 0908 日语 0909 阿拉伯语 0910 西班牙语 0911 意大利语 0912 葡萄牙语 0913 马来语 0914 荷兰语 0915 朝鲜语 0916 荷兰语 0917 俄语 0918 泰语',
    phn_brand,  -- CHAR(4) COMMENT '手机品牌: 0848 小米 0844 华为 0841 苹果 0849 OPPO 084a 三星 084b Vivo 0847 魅族 0842 酷派 0845 联想 0843 金立 0846 乐视',
    resd_ctier, -- CHAR(6) COMMENT '几线城市: 01a100 一线城市 01a200 二线城市 01a300 三线城市 01a400 三线以下城市',
    resd_city,  -- CHAR(9) COMMENT '所在城市。可选值参见相应的三级标签编码',
    --
    -- 以下是多值二级标签的三级标签值。
    --
    -- 为提高存储效率并支持以后三级标签的增加，lbcube.gaz_lbs表中的二级标签字段都采用4字节
    -- 的INT型，并按顺序用低位表示该三级标签是否存在（详情参见lbcube.gaz_lbs中的注释）。
    -- 本视图把按位存储的三级标签解析出来。如对于位为0表示不具备该标签，为1表示有该标签。
    --
    -- parent 有小孩情况
    parent IS NOT NULL AND (parent &128)>0 prn_pre_prgn,  -- 013100 备孕
    parent IS NOT NULL AND (parent &64 )>0 prn_prgn,      -- 013200 孕期
    parent IS NOT NULL AND (parent &32 )>0 prn_kids_2y,   -- 013300 0-2岁小孩父母
    parent IS NOT NULL AND (parent &16 )>0 prn_kids_6y,   -- 013400 3-6岁小孩父母
    parent IS NOT NULL AND (parent &8  )>0 prn_is_mom,    -- 013700 妈妈
    parent IS NOT NULL AND (parent &4  )>0 prn_maternal,  -- 013800 母婴
    parent IS NOT NULL AND (parent &2  )>0 prn_elm_sch,   -- 013500 小学生家长
    parent IS NOT NULL AND (parent &1  )>0 prn_hgh_sch,   -- 013600 中学生家长
    -- recent activities 最近行为
    recn_acts IS NOT NULL AND (recn_acts &4)>0 rac_moving,     -- 041000 搬家
    recn_acts IS NOT NULL AND (recn_acts &2)>0 rac_dom_trvl,   -- 042001 国内旅游
    recn_acts IS NOT NULL AND (recn_acts &1)>0 rac_ovs_trvl,   -- 042002 出境游
    -- sexual_orientation 性取向
    sex_orien IS NOT NULL AND (sex_orien &4)>0 sxor_gay,      -- 01b100 男同
    sex_orien IS NOT NULL AND (sex_orien &2)>0 sxor_les,      -- 01b200 女同
    sex_orien IS NOT NULL AND (sex_orien &1)>0 sxor_str,      -- 01b300 异性恋
    -- finance 金融理财
    finance IS NOT NULL AND (finance &64)>0 fnc_stock,      -- 021100 股票交易
    finance IS NOT NULL AND (finance &32)>0 fnc_asst_mgt,   -- 021200 投资理财
    finance IS NOT NULL AND (finance &16)>0 fnc_booking,    -- 021300 记账
    finance IS NOT NULL AND (finance &8 )>0 fnc_banking,    -- 021400 银行
    finance IS NOT NULL AND (finance &4 )>0 fnc_crdt_crd,   -- 021500 信用卡
    finance IS NOT NULL AND (finance &2 )>0 fnc_lottery,    -- 021600 彩票
    finance IS NOT NULL AND (finance &1 )>0 fnc_p2p,        -- 021700 网贷p2p
    -- shopping 购物
    shopping IS NOT NULL AND (shopping &16)>0 shp_online,     -- 022100 网购
    shopping IS NOT NULL AND (shopping &8 )>0 shp_overseas,   -- 022200 海淘
    shopping IS NOT NULL AND (shopping &4 )>0 shp_exp_deli,   -- 022300 快递
    shopping IS NOT NULL AND (shopping &2 )>0 shp_liquor,     -- 022400 酒类
    shopping IS NOT NULL AND (shopping &1 )>0 shp_grp_buy,    -- 022500 团购
    -- education 教育
    education IS NOT NULL AND (education &128)>0 edu_presch,     -- 023100 学前教育
    education IS NOT NULL AND (education &64 )>0 edu_k12,        -- 023200 中小学教育
    education IS NOT NULL AND (education &32 )>0 edu_adult,      -- 023300 成人教育
    education IS NOT NULL AND (education &16 )>0 edu_english,    -- 023400 英语培训
    education IS NOT NULL AND (education &8  )>0 edu_abroad,     -- 023500 出国培训
    education IS NOT NULL AND (education &4  )>0 edu_pro_cert,   -- 023600 考试证书
    education IS NOT NULL AND (education &2  )>0 edu_language,   -- 023700 语言学习
    education IS NOT NULL AND (education &1  )>0 edu_online,     -- 023800 在线教育
    -- travel 旅游
    travel IS NOT NULL AND (travel &16)>0 trvl_biz,       -- 024100 商务旅行
    travel IS NOT NULL AND (travel &8 )>0 trvl_leisure,   -- 024200 休闲旅行
    travel IS NOT NULL AND (travel &4 )>0 trvl_hotel,     -- 024300 酒店·住宿
    travel IS NOT NULL AND (travel &2 )>0 trvl_outdoor,   -- 024400 户外
    travel IS NOT NULL AND (travel &1 )>0 trvl_excur,     -- 024500 周边游
    -- automobile 汽车
    autom IS NOT NULL AND (autom &32)>0 autm_rental,    -- 025100 租车
    autom IS NOT NULL AND (autom &16)>0 autm_buying,    -- 025200 买车
    autom IS NOT NULL AND (autom &8 )>0 autm_test,      -- 025300 驾考
    autom IS NOT NULL AND (autom &4 )>0 autm_enthus,    -- 025400 爱车
    autom IS NOT NULL AND (autom &2 )>0 autm_drv_ser,   -- 025500 代驾
    autom IS NOT NULL AND (autom &1 )>0 autm_viola_q,   -- 026600 违章查询
    -- reading 新闻阅读
    reading IS NOT NULL AND (reading &128)>0 rd_news,        -- 026100 新闻·资讯
    reading IS NOT NULL AND (reading &64 )>0 rd_magazine,    -- 026200 杂志
    reading IS NOT NULL AND (reading &32 )>0 rd_fiction,     -- 026300 小说
    reading IS NOT NULL AND (reading &16 )>0 rd_audio_bk,    -- 026400 听书
    reading IS NOT NULL AND (reading &8  )>0 rd_comic_bk,    -- 026500 漫画
    reading IS NOT NULL AND (reading &4  )>0 rd_humors,      -- 026600 搞笑
    reading IS NOT NULL AND (reading &2  )>0 rd_pic,         -- 026700 画报
    reading IS NOT NULL AND (reading &1  )>0 rd_sports,      -- 026800 体育资讯
    -- video 影音
    video IS NOT NULL AND (video &128)>0 vd_kok,         -- 027100 K歌
    video IS NOT NULL AND (video &64 )>0 vd_player_,     -- 027200 音乐播放器
    video IS NOT NULL AND (video &32 )>0 vd_radio,       -- 027300 电台
    video IS NOT NULL AND (video &16 )>0 vd_ringtone,    -- 027400 铃声
    video IS NOT NULL AND (video &8  )>0 vd_player_v,    -- 027500 视频播放器
    video IS NOT NULL AND (video &4  )>0 vd_live_tv,     -- 027600 电视直播
    video IS NOT NULL AND (video &2  )>0 vd_online_v,    -- 027700 在线视频
    video IS NOT NULL AND (video &1  )>0 vd_online_m,    -- 027800 在线音乐
    -- social_networking 聊天社交
    social_net IS NOT NULL AND (social_net &16)>0 sns_chat,       -- 028100 聊天
    social_net IS NOT NULL AND (social_net &8 )>0 sns_casu_dt,    -- 028200 单身交友
    social_net IS NOT NULL AND (social_net &4 )>0 sns_seri_dt,    -- 028300 婚恋
    social_net IS NOT NULL AND (social_net &2 )>0 sns_twitter,    -- 028400 微博
    social_net IS NOT NULL AND (social_net &1 )>0 sns_commu,      -- 028500 社区
    -- life_service 生活服务
    life_serv IS NOT NULL AND (life_serv &8192)>0 lfs_rst_rcom,   -- 029100 餐厅推荐
    life_serv IS NOT NULL AND (life_serv &4096)>0 lfs_takeout,    -- 029200 外卖
    life_serv IS NOT NULL AND (life_serv &2048)>0 lfs_frf_deli,   -- 029300 生鲜配送
    life_serv IS NOT NULL AND (life_serv &1024)>0 lfs_hskeep,     -- 029400 找阿姨
    life_serv IS NOT NULL AND (life_serv &512) >0 lfs_laundry,    -- 029500 洗衣
    life_serv IS NOT NULL AND (life_serv &256) >0 lfs_cook_ser,   -- 029600 做饭
    life_serv IS NOT NULL AND (life_serv &128) >0 lfs_massage,    -- 029700 按摩
    life_serv IS NOT NULL AND (life_serv &64)  >0 lfs_movie,      -- 029800 电影
    life_serv IS NOT NULL AND (life_serv &32)  >0 lfs_pet,        -- 029900 宠物
    life_serv IS NOT NULL AND (life_serv &16)  >0 lfs_hs_rent,    -- 029a00 租房
    life_serv IS NOT NULL AND (life_serv &8)   >0 lfs_moving,     -- 029b00 搬家
    life_serv IS NOT NULL AND (life_serv &4)   >0 lfs_hs_buy,     -- 029c00 买房
    life_serv IS NOT NULL AND (life_serv &2)   >0 lfs_hm_deco,    -- 029d00 家装
    life_serv IS NOT NULL AND (life_serv &1)   >0 lfs_wedding,    -- 029e00 婚礼
    -- fitness 运动健康
    fitness IS NOT NULL AND (fitness &8)>0 fit,            -- 02a100 运动健身
    fitness IS NOT NULL AND (fitness &4)>0 fit_wgh_los,    -- 02a200 减肥
    fitness IS NOT NULL AND (fitness &2)>0 fit_healthc,    -- 02a300 健康医疗
    fitness IS NOT NULL AND (fitness &1)>0 fit_chronics,   -- 02a400 慢性病
    -- photo 图像
    photo IS NOT NULL AND (photo &4)>0 pht_beau_cam,   -- 02b100 拍摄美化
    photo IS NOT NULL AND (photo &2)>0 pht_pic_shar,   -- 02b200 图片分享
    photo IS NOT NULL AND (photo &1)>0 pht_vid_cam,    -- 02b300 摄像
    -- maternal 丽人母婴
    maternal IS NOT NULL AND (maternal &4)>0 mtnl_cosme,     -- 02c100 美容美妆
    maternal IS NOT NULL AND (maternal &2)>0 mtnl_paren,     -- 02c200 育儿社区
    maternal IS NOT NULL AND (maternal &1)>0 mtnl_period,    -- 02c300 经期
    -- utilities 生活实用
    utils IS NOT NULL AND (utils &8)>0 utl_car_ser,    -- 02d100 打车出行
    utils IS NOT NULL AND (utils &4)>0 utl_recipe,     -- 02d200 美食菜谱
    utils IS NOT NULL AND (utils &2)>0 utl_navig,      -- 02d300 地图导航
    utils IS NOT NULL AND (utils &1)>0 utl_weather,    -- 02d400 天气查询
    --  productivity 效率办公
    prodv IS NOT NULL AND (prodv &8)>0 pdv_cld_stor,   -- 02e100 存储云盘
    prodv IS NOT NULL AND (prodv &4)>0 pdv_office,     -- 02e200 办公软件
    prodv IS NOT NULL AND (prodv &2)>0 pdv_notebook,   -- 02e300 笔记
    prodv IS NOT NULL AND (prodv &1)>0 pdv_mailbox,    -- 02e400 邮箱
    -- operator 运营商
    tel_opr IS NOT NULL AND (tel_opr &8)>0 tlo_cmcc,       -- 086a 中国移动
    tel_opr IS NOT NULL AND (tel_opr &4)>0 tlo_cucc,       -- 086b 中国联通
    tel_opr IS NOT NULL AND (tel_opr &2)>0 tlo_ctcc,       -- 086c 中国电信
    tel_opr IS NOT NULL AND (tel_opr &1)>0 tlo_others      -- 0860 其他运营商
  FROM lbcube.gaz_lbs;

-- “盒子”数据表结构与上述LBS的相同
CREATE TABLE IF NOT EXISTS lbcube.gaz_mbx (
  id         INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  load_time  TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '入库时间',
  group_id   VARCHAR(30) NOT NULL COMMENT '分组标识',
  device_id  VARCHAR(64) NOT NULL COMMENT '设备标识的MD5值(hexdigest)',
  resd_lan   INT COMMENT '居住地的经度。范围 180000 ~ -180000。源数据精确到小数后3位，此处放大1千倍保存为整数。Null或0表示位置未知',
  resd_lat   INT COMMENT '居住地的维度。范围 90000 ~ -90000。源数据精确到小数后3位，此处放大1千倍后保存为整数。Null或0表示位置未知',
  capt_time  VARCHAR(150) COMMENT '多个“紧凑时间格式”字符串，之间用“/”分隔，表示在地理围栏里多次出现的时间。如 “20160812185409/20160812213352”',
  age        CHAR(6) COMMENT '年龄: 011100 0-17岁, 011200 18～24岁, 011300 25～34岁, 011400 35岁+',
  gender     CHAR(6) COMMENT '性别: 012100 女 012200 男',
  cnsum_lvl  CHAR(6) COMMENT '消费水平: 014100 低, 014200 中, 014300 高',
  mari_sta   CHAR(6) COMMENT '婚姻: 015100 未婚 015200 找对象 015300 已婚',
  occupa     CHAR(6) COMMENT '职业: 016100 中小学生 016200 大学生 016300 求职中 016400 白领 016700 程序员 016800 医生 016600 教师',
  car_ownr   CHAR(6) COMMENT '是否是车主: 01c100 有车',
  langu      CHAR(4) COMMENT '手机语言: 0901 中文简体 0902 中文繁体 0903 英语 0904 朝鲜语 0905 印度语 0906 越南语 0907 土耳其语 0908 日语 0909 阿拉伯语 0910 西班牙语 0911 意大利语 0912 葡萄牙语 0913 马来语 0914 荷兰语 0915 朝鲜语 0916 荷兰语 0917 俄语 0918 泰语',
  phn_brand  CHAR(4) COMMENT '手机品牌: 0848 小米 0844 华为 0841 苹果 0849 OPPO 084a 三星 084b Vivo 0847 魅族 0842 酷派 0845 联想 0843 金立 0846 乐视',
  resd_ctier CHAR(6) COMMENT '几线城市: 01a100 一线城市 01a200 二线城市 01a300 三线城市 01a400 三线以下城市',
  resd_city  CHAR(9) COMMENT '所在城市。可选值参见相应的三级标签编码',
  parent INT COMMENT '有小孩情况',
  recn_acts INT COMMENT '最近行为',
  sex_orien INT COMMENT '性取向',
  finance INT COMMENT '金融理财',
  shopping INT COMMENT '购物',
  education INT COMMENT '教育',
  travel INT COMMENT '旅游',
  autom INT COMMENT '汽车',
  reading INT COMMENT '新闻阅读',
  video INT COMMENT '影音',
  social_net INT COMMENT '聊天社交',
  life_serv INT COMMENT '生活服务',
  fitness INT COMMENT '运动健康',
  photo INT COMMENT '图像',
  maternal INT COMMENT '丽人母婴',
  utils INT COMMENT '生活实用',
  prodv INT COMMENT '效率办公',
  tel_opr INT COMMENT '运营商'
);

CREATE OR REPLACE VIEW lbcube.v_gaz_mbx AS
  SELECT
    id,
    load_time,
    group_id,
    device_id,
    resd_lan/1000.0,
    resd_lat/1000.0,
    capt_time,
    age,
    gender,
    cnsum_lvl,
    mari_sta,
    occupa,
    car_ownr,
    langu,
    phn_brand,
    resd_ctier,
    resd_city,
    parent IS NOT NULL AND (parent &128)>0 prn_pre_prgn,
    parent IS NOT NULL AND (parent &64 )>0 prn_prgn,
    parent IS NOT NULL AND (parent &32 )>0 prn_kids_2y,
    parent IS NOT NULL AND (parent &16 )>0 prn_kids_6y,
    parent IS NOT NULL AND (parent &8  )>0 prn_is_mom,
    parent IS NOT NULL AND (parent &4  )>0 prn_maternal,
    parent IS NOT NULL AND (parent &2  )>0 prn_elm_sch,
    parent IS NOT NULL AND (parent &1  )>0 prn_hgh_sch,
    recn_acts IS NOT NULL AND (recn_acts &4)>0 rac_moving,
    recn_acts IS NOT NULL AND (recn_acts &2)>0 rac_dom_trvl,
    recn_acts IS NOT NULL AND (recn_acts &1)>0 rac_ovs_trvl,
    sex_orien IS NOT NULL AND (sex_orien &4)>0 sxor_gay,
    sex_orien IS NOT NULL AND (sex_orien &2)>0 sxor_les,
    sex_orien IS NOT NULL AND (sex_orien &1)>0 sxor_str,
    finance IS NOT NULL AND (finance &64)>0 fnc_stock,
    finance IS NOT NULL AND (finance &32)>0 fnc_asst_mgt,
    finance IS NOT NULL AND (finance &16)>0 fnc_booking,
    finance IS NOT NULL AND (finance &8 )>0 fnc_banking,
    finance IS NOT NULL AND (finance &4 )>0 fnc_crdt_crd,
    finance IS NOT NULL AND (finance &2 )>0 fnc_lottery,
    finance IS NOT NULL AND (finance &1 )>0 fnc_p2p,
    shopping IS NOT NULL AND (shopping &16)>0 shp_online,
    shopping IS NOT NULL AND (shopping &8 )>0 shp_overseas,
    shopping IS NOT NULL AND (shopping &4 )>0 shp_exp_deli,
    shopping IS NOT NULL AND (shopping &2 )>0 shp_liquor,
    shopping IS NOT NULL AND (shopping &1 )>0 shp_grp_buy,
    education IS NOT NULL AND (education &128)>0 edu_presch,
    education IS NOT NULL AND (education &64 )>0 edu_k12,
    education IS NOT NULL AND (education &32 )>0 edu_adult,
    education IS NOT NULL AND (education &16 )>0 edu_english,
    education IS NOT NULL AND (education &8  )>0 edu_abroad,
    education IS NOT NULL AND (education &4  )>0 edu_pro_cert,
    education IS NOT NULL AND (education &2  )>0 edu_language,
    education IS NOT NULL AND (education &1  )>0 edu_online,
    travel IS NOT NULL AND (travel &16)>0 trvl_biz,
    travel IS NOT NULL AND (travel &8 )>0 trvl_leisure,
    travel IS NOT NULL AND (travel &4 )>0 trvl_hotel,
    travel IS NOT NULL AND (travel &2 )>0 trvl_outdoor,
    travel IS NOT NULL AND (travel &1 )>0 trvl_excur,
    autom IS NOT NULL AND (autom &32)>0 autm_rental,
    autom IS NOT NULL AND (autom &16)>0 autm_buying,
    autom IS NOT NULL AND (autom &8 )>0 autm_test,
    autom IS NOT NULL AND (autom &4 )>0 autm_enthus,
    autom IS NOT NULL AND (autom &2 )>0 autm_drv_ser,
    autom IS NOT NULL AND (autom &1 )>0 autm_viola_q,
    reading IS NOT NULL AND (reading &128)>0 rd_news,
    reading IS NOT NULL AND (reading &64 )>0 rd_magazine,
    reading IS NOT NULL AND (reading &32 )>0 rd_fiction,
    reading IS NOT NULL AND (reading &16 )>0 rd_audio_bk,
    reading IS NOT NULL AND (reading &8  )>0 rd_comic_bk,
    reading IS NOT NULL AND (reading &4  )>0 rd_humors,
    reading IS NOT NULL AND (reading &2  )>0 rd_pic,
    reading IS NOT NULL AND (reading &1  )>0 rd_sports,
    video IS NOT NULL AND (video &128)>0 vd_kok,
    video IS NOT NULL AND (video &64 )>0 vd_player_,
    video IS NOT NULL AND (video &32 )>0 vd_radio,
    video IS NOT NULL AND (video &16 )>0 vd_ringtone,
    video IS NOT NULL AND (video &8  )>0 vd_player_v,
    video IS NOT NULL AND (video &4  )>0 vd_live_tv,
    video IS NOT NULL AND (video &2  )>0 vd_online_v,
    video IS NOT NULL AND (video &1  )>0 vd_online_m,
    social_net IS NOT NULL AND (social_net &16)>0 sns_chat,
    social_net IS NOT NULL AND (social_net &8 )>0 sns_casu_dt,
    social_net IS NOT NULL AND (social_net &4 )>0 sns_seri_dt,
    social_net IS NOT NULL AND (social_net &2 )>0 sns_twitter,
    social_net IS NOT NULL AND (social_net &1 )>0 sns_commu,
    life_serv IS NOT NULL AND (life_serv &8192)>0 lfs_rst_rcom,
    life_serv IS NOT NULL AND (life_serv &4096)>0 lfs_takeout,
    life_serv IS NOT NULL AND (life_serv &2048)>0 lfs_frf_deli,
    life_serv IS NOT NULL AND (life_serv &1024)>0 lfs_hskeep,
    life_serv IS NOT NULL AND (life_serv &512) >0 lfs_laundry,
    life_serv IS NOT NULL AND (life_serv &256) >0 lfs_cook_ser,
    life_serv IS NOT NULL AND (life_serv &128) >0 lfs_massage,
    life_serv IS NOT NULL AND (life_serv &64)  >0 lfs_movie,
    life_serv IS NOT NULL AND (life_serv &32)  >0 lfs_pet,
    life_serv IS NOT NULL AND (life_serv &16)  >0 lfs_hs_rent,
    life_serv IS NOT NULL AND (life_serv &8)   >0 lfs_moving,
    life_serv IS NOT NULL AND (life_serv &4)   >0 lfs_hs_buy,
    life_serv IS NOT NULL AND (life_serv &2)   >0 lfs_hm_deco,
    life_serv IS NOT NULL AND (life_serv &1)   >0 lfs_wedding,
    fitness IS NOT NULL AND (fitness &8)>0 fit,
    fitness IS NOT NULL AND (fitness &4)>0 fit_wgh_los,
    fitness IS NOT NULL AND (fitness &2)>0 fit_healthc,
    fitness IS NOT NULL AND (fitness &1)>0 fit_chronics,
    photo IS NOT NULL AND (photo &4)>0 pht_beau_cam,
    photo IS NOT NULL AND (photo &2)>0 pht_pic_shar,
    photo IS NOT NULL AND (photo &1)>0 pht_vid_cam,
    maternal IS NOT NULL AND (maternal &4)>0 mtnl_cosme,
    maternal IS NOT NULL AND (maternal &2)>0 mtnl_paren,
    maternal IS NOT NULL AND (maternal &1)>0 mtnl_period,
    utils IS NOT NULL AND (utils &8)>0 utl_car_ser,
    utils IS NOT NULL AND (utils &4)>0 utl_recipe,
    utils IS NOT NULL AND (utils &2)>0 utl_navig,
    utils IS NOT NULL AND (utils &1)>0 utl_weather,
    prodv IS NOT NULL AND (prodv &8)>0 pdv_cld_stor,
    prodv IS NOT NULL AND (prodv &4)>0 pdv_office,
    prodv IS NOT NULL AND (prodv &2)>0 pdv_notebook,
    prodv IS NOT NULL AND (prodv &1)>0 pdv_mailbox,
    tel_opr IS NOT NULL AND (tel_opr &8)>0 tlo_cmcc,
    tel_opr IS NOT NULL AND (tel_opr &4)>0 tlo_cucc,
    tel_opr IS NOT NULL AND (tel_opr &2)>0 tlo_ctcc,
    tel_opr IS NOT NULL AND (tel_opr &1)>0 tlo_others
  FROM lbcube.gaz_mbx;
