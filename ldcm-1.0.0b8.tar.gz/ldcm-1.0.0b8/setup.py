from setuptools import setup
from distutils.core import Command
import os
import sys
import subprocess
import getpass
import glob
import codecs
import shutil
import random

appven = 'longbowsh'
appname = 'ldcm'
appver = '1.0.0b8'
mods = ('trgaz', "check if there're any new RPFs"), \
       ('ckgflw', "query GAZ for status of running flows"), \
       ('ld2cub', "load RDF data into Cube DB")

app_cfg_path = '/etc/%s' % appven

sysd_tpl_path = 'systemd'
sysd_gen_path = sysd_tpl_path + '/real'
sysd_target_tpl = sysd_tpl_path+'/target.template'
sysd_target_name = '%s_%s' %(appven, appname)
sysd_timer_tpl = sysd_tpl_path+'/timer.template'
sysd_service_tpl = sysd_tpl_path+'/service.template'
sysd_deploy_path = '/etc/systemd/system'


def read_f(fpath):
    with codecs.open(fpath, 'r', encoding='utf-8') as ff:
        tmpl = ff.read()
    return tmpl
def write_tmpl(fpath, txt):
    print 'Creating %s ...' % fpath
    with codecs.open(fpath, 'w', encoding='utf-8') as ff:
        ff.write(txt)

class SystemdBuilder(Command):
    description = 'Create the configuration files of "%s" systemd services.'%appname
    user_options = [
      ('systemd-user=', 'u', 'The user to run systemd service. default: %s .'%getpass.getuser()),
      ('python-inter=', 'p', 'The python interpreter path. default: %s .'%sys.executable),
      ]
    def initialize_options(self):
        self.systemd_user = getpass.getuser()
        self.python_inter = sys.executable
    def finalize_options(self):
        pass
    def run(self):
        if not os.path.exists('/usr/lib/systemd/'):
            raise Exception('Err: Not a systemd OS.')
        print 'Creating systemd service files in', sysd_gen_path, '...'
        if not os.path.exists(sysd_gen_path):
            os.mkdir(sysd_gen_path)
        target_script = read_f(sysd_target_tpl) % {'appven':appven,'appname':appname,
                    'timers':' '.join('%s_%s.timer'%(appven,m) for m,_ in mods)}
        write_tmpl('%s/%s.target'%(sysd_gen_path,sysd_target_name), target_script)
        timer_tmpl = read_f(sysd_timer_tpl)
        service_tmpl = read_f(sysd_service_tpl)
        for mod, mod_s in mods:
            service_name = '%s_%s' %(appven, mod)
            write_tmpl('%s/%s.timer'%(sysd_gen_path, service_name),
                timer_tmpl%dict(timer=service_name, appven=appven,
                            rand=random.choice([3,5,7,9,])))
            write_tmpl('%s/%s.service'%(sysd_gen_path,service_name),
                service_tmpl%dict(appven=appven,
                                appname=appname,
                                py=self.python_inter,
                                user=self.systemd_user,
                                mod=mod, mod_s=mod_s))

class Installer(Command):
    description = 'Install the "%s" systemd services. This command must be run by root.' % sysd_target_name
    user_options = [('start-service=', 's', 'A toggle flag to say If the service should be started after being installed.')]
    def initialize_options(self):
        self.start_service = None
    def finalize_options(self):
        pass
    def run(self):
        print 'Creating configuration files in', app_cfg_path, '...'
        if not os.path.exists(app_cfg_path):
            os.mkdir(app_cfg_path)
        shutil.copy('config/ldcm.cfg', app_cfg_path)
        shutil.copy('config/tags4db.dat', app_cfg_path)
        shutil.copy('readme.md', app_cfg_path)
        print 'Deploy systemd services from', sysd_gen_path, 'to', sysd_deploy_path, '...'
        for f in glob.glob(sysd_gen_path+'/*.*'):
            shutil.copy(f, sysd_deploy_path)
        print 'Autostart services at system boot ...'
        subprocess.call('systemctl enable %s.target'%sysd_target_name, shell=True)
        if self.start_service is not None:
            print 'Starting services ...'
            subprocess.call('systemctl start %s.target'%sysd_target_name, shell=True)
            for mod,_ in mods:
                timer_name = '%s_%s' %(appven, mod)
                subprocess.call('systemctl start %s.timer'%timer_name, shell=True)
        print install_ok_remind
install_ok_remind = '''\n%s services sucessfully installed.\n
Before you leave, please ensure the following:
    1. Settings in "%s" are correct.
    2. Cube database is created and started. Refer to
       sqls/cube.sql for the database DDLs.
    3. Systemd target "%s" are enabled and activated,
       i.e., "systemctl status %s.target"). If not yet,
       enable it by "systemctl enable %s.target" and
       start it by "systemctl start %s.target"\n''' % \
    (sysd_target_name, app_cfg_path, sysd_target_name, sysd_target_name, sysd_target_name, sysd_target_name)

class UnInstaller(Command):
    description = 'Uninstall the "%s" systemd services. This command must be run by root.' % sysd_target_name
    user_options = []
    def initialize_options(self):
        pass
    def finalize_options(self):
        pass
    def run(self):
        print 'Stopping & disabling %s systemd target ...' %sysd_target_name
        subprocess.call('systemctl stop %s.target'%sysd_target_name, shell=True)
        subprocess.call('systemctl disable %s.target'%sysd_target_name, shell=True)
        for mod,_ in mods:
            service_name = '%s_%s' %(appven, mod)
            print 'Stopping %s service ...' %service_name
            subprocess.call('systemctl stop %s.timer'%service_name, shell=True)
            subprocess.call('systemctl stop %s.service'%service_name, shell=True)
            print 'Removing %s service ...' %service_name
            os.remove(sysd_deploy_path + '/%s.timer'%service_name)
            os.remove(sysd_deploy_path + '/%s.service'%service_name)
        print 'Removing %s systemd target ...' %sysd_target_name
        os.remove(sysd_deploy_path + '/%s.target'%sysd_target_name)
        print 'Removing app configure files in %s ...' %app_cfg_path
        shutil.rmtree(app_cfg_path)
        print sysd_target_name, 'services successfully uninstalled.'

def get_dependencies():
    lines = [l.partition('#')[0].strip() for l in open('requirements.txt')]
    return [l for l in lines if l]
setup(name=appname,
    version=appver,
    description='A set of tools to retrieve data from Getui DW to longbow Cube',
    long_description=read_f('readme.md'),
    url='www.longbow.com',
    author='John Q Wang',
    author_email='john.wang@longbow.com',
    packages=[appname],
    install_requires=get_dependencies(),
    tests_require=['flask >= 0.11'],
    cmdclass={
        'build_service': SystemdBuilder,
        'install_service': Installer,
        'uninstall_service': UnInstaller,
    },
    zip_safe=False)
